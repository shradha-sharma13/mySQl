import mysql from "mysql";

var connect = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: ""
  });
  
  connect.connect(function(err: any) {
    if (err) console.log(err)
    else {
    console.log("Connected!");
    }
  });